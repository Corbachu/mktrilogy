/******************************************************************************
 File: bkgdpit.c

 Date: August 1994

 (C) Williams Entertainment

 Mortal Kombat III Pit Routines
******************************************************************************/

/* INCLUDES */
#include "u64main.h"

#include "mkbkgd.h"
#include "mkobj.h"
#include "mkos.h"
#include "mkgame.h"
#include "mkutil.h"
#include "mkfx.h"
#include "mkani.h"
#include "mkinit.h"
#include "mkpal.h"
#include "mksound.h"
#include "mkreact.h"
#include "moves.h"
#include "mkguys.h"
#include "vcache.h"

static short dummy;


void calla_mk1pitstar(void) 
{
	int i;
	OBJECT *obj;
	
	
	for (i=0;i<50;i++)
	{
		obj=make_solid_object(0xffff,2,2);	
		obj->ozval=0;
		set_noscroll(obj);
		obj->oxpos.u.intpos=randu(320)-1;
		obj->oypos.u.intpos=worldtly.u.intpos+randu(160)+20;
		insert_object(obj,&baklst3);
	}
	return;	
}

