/******************************************************************************
 File: heaparea.c

 Date: August 1994

 (C) Williams Entertainment

 Mortal Kombat III Heaparea Setup
******************************************************************************/

/* INCLUDES */
#include "u64main.h"

long long player_heap[PLAYER_HEAP_SIZE/sizeof(long long)];
