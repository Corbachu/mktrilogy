#include "u64main.h"

u64 gfx_ybuf[OS_YIELD_DATA_SIZE/sizeof(u64)+1];
